import os
import torch
import matplotlib.pyplot as plt

# torch.multiprocessing.set_start_method('spawn')
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
print('todo 0502: benchmark for pretrained_models')
# to maintain the same parameter configuration
saving_name = 'snn_module_effects_lowlight_0820_v2'
from PIL import Image
from spiking_model import *
from cann import CANN

Image.warnings.simplefilter('ignore')
import torch.utils.model_zoo
from tool_function import *

import torchvision
import torchvision.models as models

device = torch.device('cuda' if torch.cuda.is_available() else "cpu")
setup_seed(0)
# weight component of three parts
w_fps = 0.
w_gps = 0
w_dvs = 1
dvs_seq = 3
seq_len_aps = 3
seq_len_gps = 3
seq_len_dvs = 3  # for each seq_len_dvs, it will expand to three times due to the high resolution
dvs_expand = 3
expand_len = least_common_multiple([seq_len_aps, seq_len_dvs * dvs_expand, seq_len_gps])

sparse_lambdas = 2
r = 0.1
train_exp_idx = [3,5]
test_exp_idx = [7]

# path set
data_path = './NeuroVPR_Datasets/corridor/floor3/floor3_v'

# SNN_structure
cnn_arch = 'mobilenet_v2'
# combining layer (readout layers)
batch_size = 20
n_class = 100
rnn_num = 256
cann_num = 128
learning_rate = 1e-4

num_epoch = 30
num_iter = 100  # for each epoch, sample num_iter times from multiple exp.


model_names = sorted(name for name in models.__dict__
                     if name.islower() and not name.startswith("__")
                     and callable(models.__dict__[name]))

normalize = torchvision.transforms.Normalize(mean=[0.3537, 0.3537, 0.3537],
                                             std=[0.3466, 0.3466, 0.3466])

train_loader = Data(data_path, batch_size=batch_size, exp_idx=train_exp_idx, is_shuffle=True,
                    normalize=normalize, nclass=n_class,
                    seq_len_aps=seq_len_aps, seq_len_dvs=seq_len_dvs, seq_len_gps=seq_len_gps)
test_loader = Data(data_path, batch_size=batch_size, exp_idx=test_exp_idx, is_shuffle=True,
                   normalize=normalize, nclass=n_class,
                   seq_len_aps=seq_len_aps, seq_len_dvs=seq_len_dvs, seq_len_gps=seq_len_gps)

img_size = None


class MHNN(nn.Module):
    def __init__(self, num_classes=n_class, cann_num=cann_num):
        super(MHNN, self).__init__()

        self.snn = snn_model().to(device)
        self.mlp = nn.Linear(512, n_class)
        self.num_classes = num_classes



    def forward(self, inp, epoch=100):
        aps_inp = inp[0].to(device)
        gps_inp = inp[1]
        dvs_inp = inp[2].to(device)

        # get the corresponding output by different sensing modules
        # Compute ANN output
        batch_size, seq_len, channel, w, h = aps_inp.size()
        r_sumspike = self.snn(dvs_inp)

        return self.mlp(r_sumspike)


hnn = MHNN()
hnn.to(device)
optimizer = torch.optim.Adam(hnn.parameters(), lr=5e-4)
#optimizer = torch.optim.SGD(hnn.parameters(), lr=5e-3, momentum=0.9,weight_decay=1e-6)
# optimizer, _ = hnn.lr_initial_schedule(lrs=6e-3)
lr_schedule = torch.optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.5)
criterion = nn.CrossEntropyLoss()
record = {}
record['loss'], record['top1'], record['top5'], record['top10'] = [], [], [], []
best_test_acc1, best_test_acc5, best_recall, best_test_acc10 = 0., 0., 0, 0

train_iters = iter(train_loader)
iters = 0
start_time = time.time()
print(device)

import torchmetrics

best_recall = 0.
test_acc = torchmetrics.Accuracy()
# test_auc = torchmetrics.AUC(average = 'macro', num_classes=n_class)
test_recall = torchmetrics.Recall(average='none', num_classes=n_class)
test_precision = torchmetrics.Precision(average='none', num_classes=n_class)
for epoch in range(num_epoch):
    ## for training
    running_loss = 0.
    counts = 1.
    acc1_record, acc5_record, acc10_record = 0., 0., 0.
    while iters < num_iter:
        # print(iters)
        hnn.train()
        optimizer.zero_grad()
        try:
            inputs, target = next(train_iters)
        except StopIteration:
            train_iters = iter(train_loader)
            inputs, target = next(train_iters)

        outputs = hnn(inputs, epoch=epoch)
        class_loss = criterion(outputs, target.to(device))

        
        loss = class_loss 
        loss.backward()
        optimizer.step()
        running_loss += loss.cpu().item()
        acc1, acc5, acc10 = accuracy(outputs.cpu(), target, topk=(1, 5, 10))
        acc1, acc5, acc10 = acc1 / len(outputs), acc5 / len(outputs), acc10 / len(outputs)
        acc1_record += acc1
        acc5_record += acc5
        acc10_record += acc10
        counts += 1
        iters += 1.
    iters = 0
    sparse_loss = 0
    record['loss'].append(loss.item())
    print('\n\nTime elaspe:', time.time() - start_time, 's')
    print(
        'Training epoch %.1d, training loss :%.4f, sparse loss :%.4f, training Top1 acc: %.4f, training Top5 acc: %.4f' %
        (epoch, running_loss / (num_iter), sparse_lambdas * sparse_loss, acc1_record / counts, acc5_record / counts))

    lr_schedule.step()
    start_time = time.time()

    ## for testing
    running_loss = 0.
    hnn.eval()
    with torch.no_grad():
        acc1_record, acc5_record, acc10_record = 0., 0., 0.
        counts = 1.
        for batch_idx, (inputs, target) in enumerate(test_loader):
            outputs = hnn(inputs, epoch=epoch)
            loss = criterion(outputs.cpu(), target)
            running_loss += loss.item()
            acc1, acc5, acc10 = accuracy(outputs.cpu(), target, topk=(1, 5, 10))
            acc1, acc5, acc10 = acc1 / len(outputs), acc5 / len(outputs), acc10 / len(outputs)
            acc1_record += acc1
            acc5_record += acc5
            acc10_record += acc10
            counts += 1
            outputs = outputs.cpu()
            test_acc(outputs.argmax(1), target)
            test_recall(outputs.argmax(1), target)
            test_precision(outputs.argmax(1), target)

    total_acc = test_acc.compute().mean()
    total_recall = test_recall.compute().mean()
    total_precison = test_precision.compute().mean()

    # print('Test Accuracy : %.4f, Test recall : %.4f, Test Precision : %.4f'%(total_acc, total_recall,total_precison))

    test_precision.reset()
    test_recall.reset()
    test_acc.reset()

    acc1_record = acc1_record / counts
    acc5_record = acc5_record / counts
    acc10_record = acc10_record / counts

    record['top1'].append(acc1_record)
    record['top5'].append(acc5_record)
    record['top10'].append(acc10_record)

    print(
        'Testing epoch %.1d,  loss :%.4f,  Top1 acc: %.4f,  Top5 acc: %.4f,   Top10 acc: %.4f, recall: %.4f, precision: %.4f,  best Acc1 : %.4f, best Acc5 %.4f, best recall %.4f' % (
            epoch, running_loss / (batch_idx + 1), acc1_record, acc5_record, acc10_record, total_recall, total_precison,
            best_test_acc1, best_test_acc5, best_recall))

    print('Current best Top1, ', best_test_acc1, 'Best Top5, ...', best_test_acc5)

    if epoch > 1:
        if best_test_acc1 < acc1_record:
            best_test_acc1 = acc1_record
            print('Achiving the best Top1, saving...', best_test_acc1)

        if best_test_acc5 < acc5_record:
            # best_test_acc1 = acc1_record
            best_test_acc5 = acc5_record
            print('Achiving the best Top5, saving...', best_test_acc5)

        if best_recall < total_recall:
            # best_test_acc1 = acc1_record
            best_recall = total_recall
            print('Achiving the best recall, saving...', best_recall)

        if best_test_acc10 < acc10_record:
            best_test_acc10 = acc10_record

        state = {
            'net': hnn.state_dict(),
            'snn': hnn.snn.state_dict(),
            'record': record,
            'best_recall': best_recall,
            'best_acc1': best_test_acc1,
            'best_acc5': best_test_acc5,
            'best_acc10': best_test_acc10
        }
        if not os.path.isdir('../checkpoint'):
            os.mkdir('../checkpoint')
        torch.save(state, '../checkpoint/' + saving_name + '.t7')











