import os
import torch
import matplotlib.pyplot as plt

# torch.multiprocessing.set_start_method('spawn')
os.environ['CUDA_VISIBLE_DEVICES'] = "9"
print('todo 0502: benchmark for pretrained_models')
# to maintain the same parameter configuration
saving_name = 'module_effects_cann_corridor_v1_0820'
print('ANN: training:3,5; test: 7')
from PIL import Image
from small_spiking_model import *
from cann import CANN

Image.warnings.simplefilter('ignore')
import torch.utils.model_zoo
from tool_function import *

import torchvision
import torchvision.models as models

device = torch.device('cuda' if torch.cuda.is_available() else "cpu")
setup_seed(0)
# weight component of three parts
w_fps = 0
w_gps = 1
w_dvs = 0
dvs_seq = 3
seq_len_aps = 3
seq_len_gps = 3
seq_len_dvs = 3  # for each seq_len_dvs, it will expand to three times due to the high resolution
dvs_expand = 1
expand_len = least_common_multiple([seq_len_aps, seq_len_dvs * dvs_expand, seq_len_gps])

sparse_lambdas = 2
r = 0.1
train_exp_idx = [3, 5]
test_exp_idx = [7]

# path set
data_path = './NeuroVPR_Datasets/corridor/floor3/floor3_v'
snn_path = './snn_retrained_model.t7'

# SNN_structure
cnn_arch = 'mobilenet_v2'
# combining layer (readout layers)
batch_size = 20
n_class = 100
rnn_num = 256
cann_num = 128
learning_rate = 1e-4

num_epoch = 30
num_iter = 100  # for each epoch, sample num_iter times from multiple exp.
ann_pre_load = True
snn_pre_load = True
re_trained = False

w_fps_gps = int((w_gps + w_fps) > 0)

model_names = sorted(name for name in models.__dict__
                     if name.islower() and not name.startswith("__")
                     and callable(models.__dict__[name]))

normalize = torchvision.transforms.Normalize(mean=[0.3537, 0.3537, 0.3537],
                                             std=[0.3466, 0.3466, 0.3466])

train_loader = Data(data_path, batch_size=batch_size, exp_idx=train_exp_idx, is_shuffle=True,
                    normalize=normalize, nclass=n_class,
                    seq_len_aps=seq_len_aps, seq_len_dvs=seq_len_dvs, seq_len_gps=seq_len_gps)
test_loader = Data(data_path, batch_size=batch_size, exp_idx=test_exp_idx, is_shuffle=True,
                   normalize=normalize, nclass=n_class,
                   seq_len_aps=seq_len_aps, seq_len_dvs=seq_len_dvs, seq_len_gps=seq_len_gps)

img_size = None


class MHNN(nn.Module):
    def __init__(self, num_classes=n_class, cann_num=cann_num):
        super(MHNN, self).__init__()

        if ann_pre_load:
            print("=> Loading pre-trained model '{}'".format(cnn_arch))
            self.cnn = models.__dict__[cnn_arch](pretrained=ann_pre_load)
        else:
            print("=> Using randomly inizialized model '{}'".format(cnn_arch))
            self.cnn = models.__dict__[cnn_arch](pretrained=ann_pre_load)

        if cnn_arch == "resnet18":
            """ Resnet18 """
            self.feature_dim = self.cnn.fc.in_features
            self.cnn.fc = nn.Identity()

        elif cnn_arch == "mobilenet_v2":
            """ MobileNet """
            self.feature_dim = self.cnn.classifier[1].in_features
            self.cnn.classifier[1] = nn.Identity()

        else:
            print("=> Please check model name or configure architecture for feature extraction only, exiting...")
            exit()
        for param in self.cnn.parameters():
            param.requires_grad = re_trained

        self.snn = snn_model().to(device)
        self.snn_out_dim = self.snn.fc2.weight.size()[1]
        self.ann_out_dim = self.feature_dim
        self.cann_out_dim = 3 * cann_num
        self.reservior_inp_num = self.ann_out_dim + self.snn_out_dim + self.cann_out_dim
        self.LN = nn.LayerNorm(self.reservior_inp_num)
        if snn_pre_load:
            self.snn.load_state_dict(torch.load(snn_path)['snn'])

        self.cann_num = cann_num
        self.cann = None
        self.num_classes = num_classes

        self.input_size = self.feature_dim
        self.reservoir_num = 4 * 800

        self.threshold = 0.5
        self.decay = nn.Parameter(torch.rand(self.reservoir_num))

        self.K = 128
        self.num_block = 4
        self.num_blockneuron = int(self.reservoir_num / self.num_block)
        self.decay_scale = 0.5
        self.beta_scale = 0.1
        self.current_scale = 0.1

        self.thr_base1 = self.threshold
        self.thr_beta1 = nn.Parameter(self.beta_scale * torch.rand(self.reservoir_num))
        self.thr_decay1 = nn.Parameter(self.decay_scale * torch.rand(self.reservoir_num))

        self.ref_base1 = self.threshold
        self.ref_beta1 = nn.Parameter(self.beta_scale * torch.rand(self.reservoir_num))
        self.ref_decay1 = nn.Parameter(self.decay_scale * torch.rand(self.reservoir_num))

        self.cur_base1 = 0
        self.cur_beta1 = nn.Parameter(self.beta_scale * torch.rand(self.reservoir_num))
        self.cur_decay1 = nn.Parameter(self.decay_scale * torch.rand(self.reservoir_num))

        self.project = nn.Linear(self.reservior_inp_num, self.reservoir_num)
        self.project_mask_matrix = torch.zeros((self.reservior_inp_num, self.reservoir_num))
        input_node_list = [0, self.ann_out_dim, self.snn_out_dim, self.cann_num * 2, self.cann_num]
        input_cum_list = np.cumsum(input_node_list)
        for i in range(len(input_cum_list) - 1):
            self.project_mask_matrix[input_cum_list[i]:input_cum_list[i + 1],
            self.num_blockneuron * i:self.num_blockneuron * (i + 1)] = 1

        self.project.weight.data = self.project.weight.data * self.project_mask_matrix.t()

        self.lateral_conn = nn.Linear(self.reservoir_num, self.reservoir_num)
        self.lateral_conn_mask = torch.rand(self.reservoir_num, self.reservoir_num) > 0.8
        self.lateral_conn_mask = self.lateral_conn_mask * (1 - torch.eye(self.reservoir_num, self.reservoir_num))
        self.lateral_conn.weight.data = 1e-1 * self.lateral_conn.weight.data * self.lateral_conn_mask
        self.mlp1 = nn.Linear(self.reservoir_num, 256)
        self.mlp2 = nn.Linear(256, self.num_classes)

    def cann_init(self, data):
        self.cann = CANN(data)

    # def mem_update(self, fc, inputx, spike, mem, thr, ref, last_cur):
    #     state = fc(inputx)
    #     mem = (mem - spike * ref) * self.decay + state + last_cur
    #     spike = act_fun(mem - thr)
    #     # spike = F.sigmoid( (mem - thr)/self.threshold)
    #     return spike.float(), mem

    def lr_initial_schedule(self, lrs=1e-3):
        hyper_param_list = ['decay',
                            'thr_beta1', 'thr_decay1',
                            'ref_beta1', 'ref_decay1',
                            'cur_beta1', 'cur_decay1']
        hyper_params = list(filter(lambda x: x[0] in hyper_param_list, self.named_parameters()))
        base_params = list(filter(lambda x: x[0] not in hyper_param_list, self.named_parameters()))
        hyper_params = [x[1] for x in hyper_params]
        base_params = [x[1] for x in base_params]
        optimizer = torch.optim.SGD(
            [
                {'params': base_params, 'lr': lrs},
                {'params': hyper_params, 'lr': lrs / 2},
            ], lr=lrs, momentum=0.9, weight_decay=1e-7
        )
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, float(num_epoch))
        return optimizer, scheduler

    def wta_mem_update(self, fc, fv, k, inputx, spike, mem, thr, ref, last_cur):
        """
        fc: feedforward conn.
        k: winners
        """
        state = fc(inputx) + fv(spike)
        mem = (mem - spike * ref) * self.decay + state + last_cur
        q0 = 0.8
        mem = mem.reshape(batch_size, self.num_blockneuron, -1)
        nps = torch.quantile(mem, q=q0, keepdim=True, axis=1)
        mem = F.relu(mem - nps).reshape(batch_size, -1)
        spike = act_fun(mem - thr)
        return spike.float(), mem

    def trace_update(self, trace, spike, decay):
        return trace * decay + spike

    def forward(self, inp, epoch=100):
        aps_inp = inp[0].to(device)
        gps_inp = inp[1]
        dvs_inp = inp[2].to(device)

        # get the corresponding output by different sensing modules
        # Compute ANN output
        batch_size, seq_len, channel, w, h = aps_inp.size()
        if w_fps > 0:
            aps_inp = aps_inp.view(batch_size * seq_len, channel, w, h)  # 3xHXW
            aps_out = self.cnn(aps_inp)
            out1 = aps_out.reshape(batch_size, seq_len_aps, -1).permute([1,0,2])
        else:
            #out1 = torch.zeros(seq_len_aps, batch_size, -1, device=device).to(torch.float32)
            out1 = torch.zeros(seq_len_aps, batch_size, self.ann_out_dim, device=device).to(torch.float32)
        ### SNN module
        if w_dvs > 0:
            out2 = self.snn(dvs_inp, out_mode='time')
        else:
            out2 = torch.zeros(seq_len_dvs*3, batch_size, self.snn_out_dim, device=device).to(torch.float32)

        ### CANN module
        if w_gps > 0:
            gps_record = []
            for idx in range(batch_size):
                buf = self.cann.update(gps_inp[idx], trajactory_mode=True)
                gps_record.append(buf[None, :, :, :])
            gps_out = torch.from_numpy(np.concatenate(gps_record)).cuda()
            gps_out = gps_out.permute([1, 0, 2, 3]).reshape(seq_len_gps, batch_size, -1)
        else:
            gps_out = torch.zeros((seq_len_gps, batch_size, self.cann_out_dim), device = device)

        out3 = gps_out[:, :, :self.cann_num * 2].to(device).to(torch.float32)
        out4 = gps_out[:, :, -self.cann_num:].to(device).to(torch.float32)

        expand_len = int(seq_len_gps * seq_len_aps / np.gcd(seq_len_gps, seq_len_dvs) * dvs_expand)
        input_num = self.feature_dim + self.snn.fc2.weight.size()[1] + self.cann_num * dvs_expand

        r_spike = r_mem = r_sumspike = torch.zeros(batch_size, self.reservoir_num, device=device)
        thr_trace = torch.zeros(batch_size, self.reservoir_num, device=device)
        ref_trace = torch.zeros(batch_size, self.reservoir_num, device=device)
        cur_trace = torch.zeros(batch_size, self.reservoir_num, device=device)
        K_winner = self.K * (1 + np.clip(num_epoch - epoch, a_min=0, a_max=num_epoch) / num_epoch)
        out1_zeros = torch.zeros_like(out1[0], device=device)
        out3_zeros = torch.zeros_like(gps_out[0], device=device)
        self.project.weight.data = self.project.weight.data * self.project_mask_matrix.t().cuda()
        self.decay.data = torch.clamp(self.decay.data, min=0, max=1.)
        self.thr_decay1.data = torch.clamp(self.thr_decay1.data, min=0, max=1.)
        self.ref_decay1.data = torch.clamp(self.ref_decay1.data, min=0, max=1)
        self.cur_decay1.data = torch.clamp(self.cur_decay1.data, min=0, max=1)

        for step in range(expand_len):

            idx = step % 3
            if idx == 1:
                combined_input = torch.cat((out1[step // 3], out2[step], gps_out[step // 3]), axis=1)
            else:
                combined_input = torch.cat((out1_zeros, out2[step], out3_zeros), axis=1)

            # paramter update
            thr = self.thr_base1 + thr_trace * self.thr_beta1
            ref = self.ref_base1 + ref_trace * self.ref_beta1
            cur = self.cur_base1 + cur_trace * self.cur_beta1

            inputx = combined_input.float()
            r_spike, r_mem = self.wta_mem_update(self.project, self.lateral_conn, K_winner, inputx, r_spike, r_mem,
                                                 thr, ref, cur)
            # trace update
            thr_trace = self.trace_update(thr_trace, r_spike, self.thr_decay1)
            ref_trace = self.trace_update(ref_trace, r_spike, self.ref_decay1)
            cur_trace = self.trace_update(cur_trace, r_spike, self.cur_decay1)

            # sumamation of spikes
            r_sumspike = r_sumspike + r_spike

        # cat_out = F.dropout(r_sumspike, p=0.5, training=self.training)
        out1 = self.mlp1(r_sumspike).relu()
        out2 = self.mlp2(out1)
        neuron_pop = r_sumspike.reshape(batch_size, -1, self.num_blockneuron).permute([1, 0, 2])
        return out2, (neuron_pop[0], neuron_pop[1], neuron_pop[2], neuron_pop[3])


hnn = MHNN()
hnn.cann_init(train_loader.dataset.data_pos[0])
hnn.to(device)
optimizer = torch.optim.Adam(hnn.parameters(), lr=5e-4)
# optimizer = torch.optim.SGD(hnn.parameters(), lr=3e-3, momentum=0.9, weight_decay=1e-7)
# lr_schedule = torch.optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.5)

# optimizer, _ = hnn.lr_initial_schedule(lrs=6e-3)
lr_schedule = torch.optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.5)
criterion = nn.CrossEntropyLoss()
record = {}
record['loss'], record['top1'], record['top5'], record['top10'] = [], [], [], []
best_test_acc1, best_test_acc5, best_recall, best_test_acc10 = 0., 0., 0, 0

train_iters = iter(train_loader)
iters = 0
start_time = time.time()
print(device)

import torchmetrics

best_recall = 0.
test_acc = torchmetrics.Accuracy()
# test_auc = torchmetrics.AUC(average = 'macro', num_classes=n_class)
test_recall = torchmetrics.Recall(average='none', num_classes=n_class)
test_precision = torchmetrics.Precision(average='none', num_classes=n_class)
for epoch in range(num_epoch):
    ## for training
    running_loss = 0.
    counts = 1.
    acc1_record, acc5_record, acc10_record = 0., 0., 0.
    while iters < num_iter:
        # print(iters)
        hnn.train()
        optimizer.zero_grad()
        try:
            inputs, target = next(train_iters)
        except StopIteration:
            train_iters = iter(train_loader)
            inputs, target = next(train_iters)

        outputs, outs = hnn(inputs, epoch=epoch)
        class_loss = criterion(outputs, target.to(device))

        sparse_loss = 0.
        w_module = (w_fps, w_dvs, w_gps, w_gps)
        for (i, l) in enumerate(outs):
            sparse_loss += (l.mean() - r)**2 * w_module[i]

        loss = class_loss + sparse_lambdas * sparse_loss
        loss.backward()
        optimizer.step()
        running_loss += loss.cpu().item()
        acc1, acc5, acc10 = accuracy(outputs.cpu(), target, topk=(1, 5, 10))
        acc1, acc5, acc10 = acc1 / len(outputs), acc5 / len(outputs), acc10 / len(outputs)
        acc1_record += acc1
        acc5_record += acc5
        acc10_record += acc10
        counts += 1
        iters += 1.
    iters = 0

    record['loss'].append(loss.item())
    print('\n\nTime elaspe:', time.time() - start_time, 's')
    print(
        'Training epoch %.1d, training loss :%.4f, sparse loss :%.4f, training Top1 acc: %.4f, training Top5 acc: %.4f' %
        (epoch, running_loss / (num_iter), sparse_lambdas * sparse_loss, acc1_record / counts, acc5_record / counts))

    lr_schedule.step()
    start_time = time.time()

    ## for testing
    running_loss = 0.
    hnn.eval()
    with torch.no_grad():
        acc1_record, acc5_record, acc10_record = 0., 0., 0.
        counts = 1.
        for batch_idx, (inputs, target) in enumerate(test_loader):
            outputs, _ = hnn(inputs, epoch=epoch)
            loss = criterion(outputs.cpu(), target)
            running_loss += loss.item()
            acc1, acc5, acc10 = accuracy(outputs.cpu(), target, topk=(1, 5, 10))
            acc1, acc5, acc10 = acc1 / len(outputs), acc5 / len(outputs), acc10 / len(outputs)
            acc1_record += acc1
            acc5_record += acc5
            acc10_record += acc10
            counts += 1
            outputs = outputs.cpu()
            test_acc(outputs.argmax(1), target)
            test_recall(outputs.argmax(1), target)
            test_precision(outputs.argmax(1), target)

    total_acc = test_acc.compute().mean()
    total_recall = test_recall.compute().mean()
    total_precison = test_precision.compute().mean()

    # print('Test Accuracy : %.4f, Test recall : %.4f, Test Precision : %.4f'%(total_acc, total_recall,total_precison))

    test_precision.reset()
    test_recall.reset()
    test_acc.reset()

    acc1_record = acc1_record / counts
    acc5_record = acc5_record / counts
    acc10_record = acc10_record / counts

    record['top1'].append(acc1_record)
    record['top5'].append(acc5_record)
    record['top10'].append(acc10_record)

    print(
        'Testing epoch %.1d,  loss :%.4f,  Top1 acc: %.4f,  Top5 acc: %.4f,   Top10 acc: %.4f, recall: %.4f, precision: %.4f,  best Acc1 : %.4f, best Acc5 %.4f, best recall %.4f' % (
            epoch, running_loss / (batch_idx + 1), acc1_record, acc5_record, acc10_record, total_recall, total_precison,
            best_test_acc1, best_test_acc5, best_recall))

    print('Current best Top1, ', best_test_acc1, 'Best Top5, ...', best_test_acc5)

    if epoch > 4:
        if best_test_acc1 < acc1_record:
            best_test_acc1 = acc1_record
            print('Achiving the best Top1, saving...', best_test_acc1)

        if best_test_acc5 < acc5_record:
            # best_test_acc1 = acc1_record
            best_test_acc5 = acc5_record
            print('Achiving the best Top5, saving...', best_test_acc5)

        if best_recall < total_recall:
            # best_test_acc1 = acc1_record
            best_recall = total_recall
            print('Achiving the best recall, saving...', best_recall)

        if best_test_acc10 < acc10_record:
            best_test_acc10 = acc10_record

        state = {
            'net': hnn.state_dict(),
            'snn': hnn.snn.state_dict(),
            'record': record,
            'best_recall': best_recall,
            'best_acc1': best_test_acc1,
            'best_acc5': best_test_acc5,
            'best_acc10': best_test_acc10
        }

        if not os.path.isdir('../checkpoint'):
            os.mkdir('../checkpoint')
        torch.save(state, '../checkpoint/' + saving_name + '.t7')











